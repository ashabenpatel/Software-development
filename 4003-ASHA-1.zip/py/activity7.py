#START
# Expression 1
result1 = 8/4 + (2 - 1) * 4

# Expression 2
result2 = 6 + (10 - 3) * 2/(1 + 1)

# Expression 3
result3 = 5 + (12/6 + 3) * 3

# Print the results
print("Result 1:", result1)
print("Result 2:", result2)
print("Result 3:", result3)
#END



