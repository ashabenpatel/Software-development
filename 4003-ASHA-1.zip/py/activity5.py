#START

# Initialize variables
num_items = 5
sales_tax_rate = 0.07
subtotal = 0

# Ask for the price of each item and calculate subtotal
for i in range(num_items):
    price = float(input("Enter the price of item {}: $".format(i + 1)))
    subtotal += price

# Calculate total sales tax
total_sales_tax = subtotal * sales_tax_rate

# Calculate total cost
total_cost = subtotal + total_sales_tax

# Display the results
print("Subtotal: ${:.2f}".format(subtotal))
print("Sales Tax: ${:.2f}".format(total_sales_tax))
print("Total Cost: ${:.2f}".format(total_cost))


#END
