# START
radius = float(input("Enter the radius: "))  # Prompt the user to enter the radius
area = 3.14159 * radius ** 2  # Calculate the area using the formula π * radius^2
print("Area of the circle:", area)  # Display the calculated area
# END