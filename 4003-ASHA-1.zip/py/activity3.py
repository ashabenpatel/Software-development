# START
# Prompt the user to enter the projected amount of total sales
total_sales = float(input("Enter the projected amount of total sales: "))

# Calculate the profit as 23% of the total sales
profit = 0.23 * total_sales

# Display the profit
print("The profit from the projected total sales is:", profit)
# END
