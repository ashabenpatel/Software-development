#START
# Step 1: Prompt the user to enter the total square feet in the tract of land
total_square_feet = float(input("Enter the total square feet in the tract of land: "))

# Step 2: Calculate the number of acres in the tract
acres = total_square_feet / 43560

# Step 3: Display the calculated number of acres
print("The number of acres in the tract of land is:", acres)

#END