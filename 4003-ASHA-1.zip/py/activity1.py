# START
kilometers = float(input("Enter the distance in kilometers: "))
miles = kilometers * 0.621371
print("Equivalent distance in miles:", miles)
# END