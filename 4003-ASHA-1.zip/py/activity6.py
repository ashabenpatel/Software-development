# Ask the user to enter the amount of purchase
purchase_amount = float(input("Enter the amount of the purchase: $"))

# Define state and county sales tax rates
state_sales_tax_rate = 0.05
county_sales_tax_rate = 0.025

# Calculate state and county sales tax
state_sales_tax = purchase_amount * state_sales_tax_rate
county_sales_tax = purchase_amount * county_sales_tax_rate

# Calculate total sales tax
total_sales_tax = state_sales_tax + county_sales_tax

# Calculate total sale (amount of purchase plus total sales tax)
total_sale = purchase_amount + total_sales_tax

# Display the results
print("Amount of the purchase: ${:.2f}".format(purchase_amount))
print("State sales tax: ${:.2f}".format(state_sales_tax))
print("County sales tax: ${:.2f}".format(county_sales_tax))
print("Total sales tax: ${:.2f}".format(total_sales_tax))
print("Total of the sale: ${:.2f}".format(total_sale))
